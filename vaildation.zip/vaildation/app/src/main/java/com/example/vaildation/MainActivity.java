package com.example.vaildation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText name,age,Pass,Phnumber;
    Button sub;
    String n,a,pa,ph;

    Pattern NAME =Pattern.compile("^[A-Za-z]\\w{5,15}$");
    Pattern PASSWORD =Pattern.compile("^" +

            "(?=.*[@#$%^&+=*])" +
            "(?=\\S+$)" +
            ".{8,}" +
            "(.*[0-9].*)"+
            "(.*[A-Z].*)"+
            "$");
    Pattern AGE=Pattern.compile("^[0-9]{1,2}$");
    Pattern PHONE=Pattern.compile("^(0|91)?[7-9][0-9]{9}$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.Name);
        age = findViewById(R.id.Age);
        Pass = findViewById(R.id.Password);
        Phnumber = findViewById(R.id.PhoneNum);
        sub = findViewById(R.id.Submit);

        sub.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(View v) {

                String inpname = name.getText().toString();
                String inpage = age.getText().toString();
                String inppass = Pass.getText().toString();
                String inpphone = Phnumber.getText().toString();


                if(inpname.isEmpty()){
                    Toast.makeText(MainActivity.this,  "Name Field is Empty", Toast.LENGTH_SHORT).show();
                }
                if(inpage.isEmpty()){
                    Toast.makeText(MainActivity.this,  "Age Field is Empty", Toast.LENGTH_SHORT).show();
                }
                if(inpphone.isEmpty()){
                    Toast.makeText(MainActivity.this,  "Phone Number Field is Empty", Toast.LENGTH_SHORT).show();
                }
                if(inppass.isEmpty()){
                    Toast.makeText(MainActivity.this,  "Password Field is Empty", Toast.LENGTH_SHORT).show();
                }
                if (!NAME.matcher(inpname).matches()){
                    name.setError("Enter alphabets [5-15 characters]");
                }
                if (!AGE.matcher(inpage).matches()){
                    age.setError("Enter Only 2 Digits");
                }
                if (!PHONE.matcher(inpphone).matches()){
                    Phnumber.setError("Should Contain 10 Digits");
                }
                if (!PASSWORD.matcher(inppass).matches()){
                    Pass.setError("Password is not Strong[Include Combination of Capital Letters,Small Letters,Digits and Special Characters]");
                }
                else Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();

            }
        });
    }
}





